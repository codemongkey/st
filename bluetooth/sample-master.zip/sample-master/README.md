### ATWILC3000 Samples for WLAN and Bluetooth

<a href="http://www.atmel.com"><img src="http://www.atmel.com/Images/atmel.png" align="left" hspace="10" vspace="6"></a>

This repository provides simple samples for Linux. Refer to the [wiki](https://github.com/atwilc3000/driver/wiki) to find usefull instructions and information for wireless solutions. 

For more information on Atmel SmartConnect, visit [Atmel SmartConnect](http://www.atmel.com/products/wireless/wifi/smart-connect.aspx).
